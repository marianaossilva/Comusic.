
+-------------------------+
|       Time Series	      |
+-------------------------+

Each of the 30 ego networks produces three time series archived in three different folders:

+-------------------+
|      Collab       |
+-------------------+

Daily time series containing the total number of musical collaborations over time. 

+---------------------------------------------------------------------------+

╔═════════════════════════════════════════════════════════╗
║                   Dataset description                   ║
╠═══════════════╦═════════════════════════════════════════╣
║   ego_label   ║    The Spotify ID for the ego artist.   ║
╠═══════════════╬═════════════════════════════════════════╣
║    ego_name   ║       The name of the ego artist.       ║
╠═══════════════╬═════════════════════════════════════════╣
║  artist_label ║   The Spotify ID for the alter artist.  ║
╠═══════════════╬═════════════════════════════════════════╣
║  artist_name  ║      The name of the alter artist.      ║
╠═══════════════╬═════════════════════════════════════════╣
║  release_date ║  The date the song was first released.  ║
╠═══════════════╬═════════════════════════════════════════╣
║     total     ║     Total number of collaborations.     ║
╠═══════════════╬═════════════════════════════════════════╣
║ total_scalled ║ Total number of collaborations scalled. ║
╚═══════════════╩═════════════════════════════════════════╝

+---------------------------------------------------------------------------+

+-------------------+
|       Solo        |
+-------------------+

Daily time series containing the total number of solo songs over time.

+---------------------------------------------------------------------------+

╔═══════════════════════════════════════════════════════╗
║                  Dataset description                  ║
╠═══════════════╦═══════════════════════════════════════╣
║   ego_label   ║   The Spotify ID for the ego artist.  ║
╠═══════════════╬═══════════════════════════════════════╣
║    ego_name   ║      The name of the ego artist.      ║
╠═══════════════╬═══════════════════════════════════════╣
║  artist_label ║  The Spotify ID for the alter artist. ║
╠═══════════════╬═══════════════════════════════════════╣
║  artist_name  ║     The name of the alter artist.     ║
╠═══════════════╬═══════════════════════════════════════╣
║  release_date ║ The date the song was first released. ║
╠═══════════════╬═══════════════════════════════════════╣
║     total     ║      Total number of solo songs.      ║
╠═══════════════╬═══════════════════════════════════════╣
║ total_scalled ║  Total number of solo songs scalled.  ║
╚═══════════════╩═══════════════════════════════════════╝

+---------------------------------------------------------------------------+

+-------------------+
|        Pop        |
+-------------------+

Daily time series containing the artist's success measure over time.

+---------------------------------------------------------------------------+

╔══════════════════════════════════════════════════════════════════════════╗
║                            Dataset description                           ║
╠════════════╦═════════════════════════════════════════════════════════════╣
║   artist   ║                 The name of the ego artist.                 ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║   peakPos  ║           The track's peak position on the chart.           ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║   lastPos  ║      The track's position on the previous week's chart.     ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║    weeks   ║ The number of weeks the track has been or was on the chart. ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║    rank    ║          The track's current position on the chart.         ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║    isNew   ║            Whether the track is new to the chart.           ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║    date    ║              The date of the week of the chart.             ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║    chart   ║               The name of the Billboard chart.              ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║  rankScore ║                     The rankscore value.                    ║
╠════════════╬═════════════════════════════════════════════════════════════╣
║ rankScaled ║                 The rankscore value scalled.                ║
╚════════════╩═════════════════════════════════════════════════════════════╝