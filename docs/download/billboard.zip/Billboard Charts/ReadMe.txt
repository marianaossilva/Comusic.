
+-------------------------+
|    Billboard Charts	  |
+-------------------------+

Data from some of the Billboard charts. Data were collected in 2018.

+---------------------------------------------------------------------------+

╔════════════════════════════════════════════════════════════════╗
║                              Files                             ║
╠════════════════════╦═══════════════════════════════════════════╣
║     hot100.csv     ║   Data collected from Hot 100 Billboard.  ║
╠════════════════════╬═══════════════════════════════════════════╣
║ top100_artists.csv ║ Data collected from Artist 100 Billboard. ║
╚════════════════════╩═══════════════════════════════════════════╝

+---------------------------------------------------------------------------+

╔═════════════════════════════════════════════════════════════════════════╗
║                           Dataset description                           ║
╠═════════╦═══════════════════════════════════════════════════════════════╣
║   date  ║                         Ranking date.                         ║
╠═════════╬═══════════════════════════════════════════════════════════════╣
║  title  ║                    The title of the track.                    ║
╠═════════╬═══════════════════════════════════════════════════════════════╣
║  artist ║     The name of the artist, as formatted on Billboard.com.    ║
╠═════════╬═══════════════════════════════════════════════════════════════╣
║ peakPos ║ The track's peak position on the chart at any point in time,  ║
║         ║               including future dates, as an int               ║
║         ║   (or None if the chart does not include this information).   ║
╠═════════╬═══════════════════════════════════════════════════════════════╣
║  weeks  ║  The number of weeks the track has been or was on the chart,  ║
║         ║      including future dates (up until the present time).      ║
╠═════════╬═══════════════════════════════════════════════════════════════╣
║   rank  ║           The track's current position on the chart.          ║
╚═════════╩═══════════════════════════════════════════════════════════════╝