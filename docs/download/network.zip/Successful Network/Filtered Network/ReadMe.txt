
+-------------------------+
|    Filtered Network	  |
+-------------------------+

This collaboration network is the result of filtering the Original network. To create a network of successful artists, we only filter artists who have a popularity level greater than 70 and a number of followers approximately greater than 1,000,000. The two metrics filtered here were collected from the features of the artists present on the Spotify platform.

+---------------------------------------------------------------------------+

╔═════════════════════════╗
║    Dataset statistics   ║
╠════════════╦════════════╣
║    Nodes   ║     354    ║
╠════════════╬════════════╣
║    Edges   ║     922    ║
╠════════════╬════════════╣
║    Type    ║ Undirected ║
╠════════════╬════════════╣
║ Modularity ║    0.472   ║
╚════════════╩════════════╝

+---------------------------------------------------------------------------+

╔═════════════════════════════════════════════════════════════════════════╗
║                                  Files                                  ║
╠═══════════════════════╦═════════════════════════════════════════════════╣
║       nodes.csv       ║        List of artists (nodes), artists'        ║
║                       ║ features and the result of topological metrics. ║
╠═══════════════════════╬═════════════════════════════════════════════════╣
║      edgelist.csv     ║     List of musical collaborations (edges)      ║
║                       ║         and some features of the songs.         ║
╠═══════════════════════╬═════════════════════════════════════════════════╣
║ filtered_network.gexf ║         GEXF (Graph Exchange XML Format)        ║
╚═══════════════════════╩═════════════════════════════════════════════════╝

