
+-------------------------+
|    Original Network	  |
+-------------------------+

This collaboration network encompasses musical collaborations among artists in the Billboard Artist 100 ranking (as well as artists who participated in the 10 most famous songs of each chart artist). If an artist participates in the performance of a song with another artist (b), the graph contains an unadjusted edge from (a) to (b). If the artists have collaborated together more than once, the edge gets heavy. Data covers artists on the chart in the Julh period from 2014 to July 2018.

+---------------------------------------------------------------------------+

╔═════════════════════════╗
║    Dataset statistics   ║   
╠════════════╦════════════╣
║    Nodes   ║    2152    ║
╠════════════╬════════════╣
║    Edges   ║     922    ║
╠════════════╬════════════╣
║    Type    ║ Undirected ║
╠════════════╬════════════╣
║ Modularity ║    0.471   ║
╚════════════╩════════════╝

+---------------------------------------------------------------------------+

╔═════════════════════════════════════════════════════════════════════════╗
║                                  Files                                  ║
╠═══════════════════════╦═════════════════════════════════════════════════╣
║       nodes.csv       ║        List of artists (nodes), artists'        ║
║                       ║ features and the result of topological metrics. ║
╠═══════════════════════╬═════════════════════════════════════════════════╣
║      edgelist.csv     ║     List of musical collaborations (edges)      ║
║                       ║         and some features of the songs.         ║
╠═══════════════════════╬═════════════════════════════════════════════════╣
║ original_network.gexf ║         GEXF (Graph Exchange XML Format)        ║
╚═══════════════════════╩═════════════════════════════════════════════════╝