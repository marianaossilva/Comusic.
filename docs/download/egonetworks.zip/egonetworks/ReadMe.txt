
+-------------------------+
|       Ego Networks      |
+-------------------------+

All 30 ego networks, where the top 30 artists represent the ego nodes and their musical collaborations, the alter nodes.

╔═════════════════════════════════════════════════════════╗
║                   Dataset description                   ║
╠═══════════════╦═════════════════════════════════════════╣
║   ego_label   ║    The Spotify ID for the ego artist.   ║
╠═══════════════╬═════════════════════════════════════════╣
║    ego_name   ║       The name of the ego artist.       ║
╠═══════════════╬═════════════════════════════════════════╣
║  artist_label ║   The Spotify ID for the alter artist.  ║
╠═══════════════╬═════════════════════════════════════════╣
║  artist_name  ║      The name of the alter artist.      ║
╠═══════════════╬═════════════════════════════════════════╣
║  release_date ║  The date the song was first released.  ║
╠═══════════════╬═════════════════════════════════════════╣
║     total     ║     Total number of collaborations.     ║
╚═══════════════╩═════════════════════════════════════════╝